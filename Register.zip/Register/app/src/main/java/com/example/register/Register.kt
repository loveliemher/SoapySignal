package com.example.register

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class Register : AppCompatActivity() {

    private lateinit var etFullName: EditText
    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var cbAgree: CheckBox
    private lateinit var btnCreateAccount: Button
    private lateinit var btnGoogle: Button
    private lateinit var tvSignIn: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)

        etFullName = findViewById(R.id.etFullName)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        cbAgree = findViewById(R.id.cbAgree)
        btnCreateAccount = findViewById(R.id.btnCreateAccount)
        btnGoogle = findViewById(R.id.btnGoogle)
        tvSignIn = findViewById(R.id.tvSignIn)

        btnCreateAccount.setOnClickListener {
            validateInputs()
        }

        btnGoogle.setOnClickListener {
            Toast.makeText(this, "Google sign-up coming soon!", Toast.LENGTH_SHORT).show()
        }

        tvSignIn.setOnClickListener {
            Toast.makeText(this, "Redirecting to Sign In...", Toast.LENGTH_SHORT).show()
        }
    }

    private fun validateInputs() {
        val fullName = etFullName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()
        val confirmPassword = etConfirmPassword.text.toString().trim()

        if (fullName.isEmpty()) {
            etFullName.error = "Please enter your full name"
            return
        }

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.error = "Enter a valid email"
            return
        }

        if (password.length < 6) {
            etPassword.error = "Password must be at least 6 characters"
            return
        }

        if (confirmPassword != password) {
            etConfirmPassword.error = "Passwords do not match"
            return
        }

        if (!cbAgree.isChecked) {
            Toast.makeText(this, "Please agree to the terms first", Toast.LENGTH_SHORT).show()
            return
        }

        Toast.makeText(this, "Account created successfully!", Toast.LENGTH_LONG).show()
    }
}
