package com.example.register

class LoginActivity {
}